# Todas as Tabelas #

## Tabela "creatures" ##

Essa tabela armazena todas as criaturas possíveis (ou seja, as criaturas base do jogo). Elas não são parte da coleção.
