enum DimensionEnum {
  terra,
  cu,
  penis,
  pau
}