enum Elemento { 
  fogo,
  agua,
  terra,
  ar,
  nulo,
  planta }
