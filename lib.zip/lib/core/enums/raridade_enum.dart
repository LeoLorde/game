enum Raridade{
  combatente,
  mistico,
  heroi,
  semideus,
  deus,
  nulo
}